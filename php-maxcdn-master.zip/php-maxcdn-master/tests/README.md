# How to Test
====================================
Included is a very simple sample API client.  In order to use this you must execute composer from the root.

Please see: http://http://getcomposer.org/ for more information.
